Conditional Branching Example
Dr Glen Pennington
Liverpool Hope University
Email: penning@hope.ac.uk
Twitter: @Dr_GP_PhD

This is not a complete experiment.  It is a starter template to allow you to present only one set of trials to a group. Typically this would be used for a between participant design.

In this example the participant must choose a pet preference (set as images cat and dog).
If they press cat, then thye see trials only relating to cats, if they press dog, they only see trials relation to dogs.


